import numpy
import cv2
import os, os.path

rootdirs = ["Marcel-Train"] #"Marcel-Train"
types = ["A", "B", "C", "Five", "Point", "V"]

for rootdir in rootdirs:
	for type in types:
		subdir = rootdir + "/" + type

		arr = os.listdir(subdir)

		index = 0

		for filename in arr:
			index = index + 1
			oldpath = subdir + "/" + filename
			newpath = subdir + "/" + str(index) + ".ppm"
			os.rename(oldpath, newpath)