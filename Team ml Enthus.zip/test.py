NUMCLASS = 6
IMAGESIZE = 125

from sklearn.datasets import load_files       
from keras.utils import np_utils
import numpy as np
from glob import glob

# define function to load train, test, and validation datasets
def load_dataset(path):
    data = load_files(path)
    dog_files = np.array(data['filenames'])
    dog_targets = np_utils.to_categorical(np.array(data['target']), NUMCLASS)
    return dog_files, dog_targets

# load train, test, and validation datasets
train_files, train_targets = load_dataset('Marcel-Train')
valid_files, valid_targets = load_dataset('Marcel-Train')
test_files, test_targets = load_dataset('cross_validation_data')

'''
def load_dataset_output(path):
    data = load_files(path)
    dog_files = np.array(data['filenames'])
    return dog_files


test_files = load_dataset_output("cross_validation_data")
'''

dog_names = [item[13:-1] for item in sorted(glob("Marcel-Train/*/"))]




from keras.preprocessing import image                  
from tqdm import tqdm
import cv2

def path_to_tensor(img_path):

    # loads RGB image as PIL.Image.Image type
    img = image.load_img(img_path, target_size=(IMAGESIZE, IMAGESIZE))
    # convert PIL.Image.Image type to 3D tensor with shape (224, 224, 3)
    x = image.img_to_array(img)

    # convert 3D tensor to 4D tensor with shape (1, 224, 224, 3) and return 4D tensor
    return np.expand_dims(x, axis=0)

def paths_to_tensor(img_paths):
    list_of_tensors = [path_to_tensor(img_path) for img_path in tqdm(img_paths)]
    return np.vstack(list_of_tensors)
                             

from PIL import ImageFile                            
ImageFile.LOAD_TRUNCATED_IMAGES = True                 

# pre-process the data for Keras
train_tensors = paths_to_tensor(train_files).astype('float32')/255
valid_tensors = paths_to_tensor(valid_files).astype('float32')/255
test_tensors = paths_to_tensor(test_files).astype('float32')/255



from keras.layers import Conv2D, MaxPooling2D, GlobalAveragePooling2D
from keras.layers import Dropout, Flatten, Dense, Activation, Dropout, Flatten
from keras.models import Sequential

model = Sequential()

### TODO: Define your architecture.
model.add(Conv2D(filters=16, kernel_size=2, padding='same', activation='relu', 
                        input_shape=(IMAGESIZE, IMAGESIZE, 3)))
model.add(MaxPooling2D(pool_size=2))
model.add(Conv2D(filters=32, kernel_size=2, padding='same', activation='relu'))
model.add(MaxPooling2D(pool_size=2))
model.add(Conv2D(filters=64, kernel_size=2, padding='same', activation='relu'))
model.add(MaxPooling2D(pool_size=2))

model.add(Flatten())  # this converts our 3D feature maps to 1D feature vectors
#model.add(Dense(64))
#model.add(Activation('relu'))
model.add(Dropout(0.25))
#model.add(Dense(1))

model.add(Dense(6, activation='softmax'))

model.summary()



model.compile(optimizer='rmsprop', loss='categorical_crossentropy', metrics=['accuracy'])



'''

model_json = model.to_json()
with open("model.json", "w") as json_file:
    json_file.write(model_json)
# serialize weights to HDF5
model.save_weights("model.h5")
'''






from keras.callbacks import ModelCheckpoint  

### TODO: specify the number of epochs that you would like to use to train the model.

epochs = 1

### Do NOT modify the code below this line.

checkpointer = ModelCheckpoint(filepath='saved_models/weights.best.from_scratch.hdf5', 
                               verbose=1, save_best_only=True)

batch_size = 10

'''
model.fit(train_tensors, train_targets, 
          validation_data=(valid_tensors, valid_targets),
          epochs=epochs, batch_size = batch_size, callbacks=[checkpointer], verbose=1)
'''

from keras.preprocessing.image import ImageDataGenerator, array_to_img, img_to_array, load_img

train_datagen = ImageDataGenerator(
        rescale=1./255,
        shear_range=0.2,
        zoom_range=0.2,
        horizontal_flip=True,
        vertical_flip=True,
        zoom_range=0.4,
        shear_range=0.4,
        zoom_range=0.8)

train_generator = train_datagen.flow_from_directory(
        'Marcel-Train',  # this is the target directory
        target_size=(IMAGESIZE, IMAGESIZE),  # all images will be resized to 150x150
        batch_size=batch_size,
        class_mode='categorical')  # since we use binary_crossentropy loss, we need binary labels

model.fit_generator(train_generator, 
          steps_per_epoch=2000 // batch_size,
        epochs=4,
        validation_data=train_generator,
        validation_steps=800 // batch_size)







import os.path




# get index of predicted dog breed for each image in test set
predictions = [np.argmax(model.predict(np.expand_dims(tensor, axis=0))) for tensor in test_tensors]

for i in xrange(0, len(test_files)):
    print os.path.basename(test_files[i]) + "," + dog_names[predictions[i]]



model.save("model.h5")

'''
# report test accuracy
test_accuracy = 100*np.sum(np.array(predictions)==np.argmax(test_targets, axis=1))/len(predictions)
print('Test accuracy: %.4f%%' % test_accuracy)
'''