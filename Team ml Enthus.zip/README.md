Team Name: mL enthus
Problem: Samsung: Hand Gesture Recognition

Process for recognition of Image Hand Gestures:

1. Place all the images to predict inside file cross_validation_data/A/
	Eg:
		-validation_data/A/
			-validation_data/A/1.ppm
			-validation_data/A/2.ppm
			-validation_data/A/3.ppm
			-....

2. Filter the input images by executing imageconvert.py
		python imageconvert.py

	All the images inside validation_data/A folder would be filtered. The process for image filter is as follows:
		- Convert image into grayscale image
		- Apply adaptive threshold to convert image file into a binary image file
		- The above process is done using OpenCV

			img = cv2.imread(imgpath)
			grey = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) # 38.23 %
			th1 = cv2.adaptiveThreshold(grey,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY,11,2) #46.47 %

3. Predict output for input images by executing gen2.py
		python gen2.py

	The output predictions would be printed in the terminal

	Example:
		3.ppm,A
		5.ppm,V
		1.ppm,V
		2.ppm,V
		4.ppm,A

	Sort the output manually in lexographic order using any tool / website. (We used http://textmechanic.com/text-tools/basic-text-tools/sort-text-lines/ for sorting easily)

	The output would be generated as:
		1.ppm,V
		2.ppm,V
		3.ppm,A
		4.ppm,A
		5.ppm,V

Process for Training data:

	1. Put all the train data inside folder: Marcel-Train
		Example folder structure:
			- Marcel-Train
				- Marcel-Train / A
					- Marcel-Train / A / 1.ppm
					- ....
				- Marcel-Train / B
					- Marcel-Train / B / 1.ppm
					- ....
				- .....

	2. Filter the input images by executing imageconvert.py
		python imageconvert.py
			(The process is same as in above topic)

	3. Execute test.py to train the data
		python test.py

		The model would be saved in model.h5 file which is then loaded back through file gen2.py
		If there are any files inside folder cross_validation_data, then the output for the same is also generated

Files included:
	- imageconvert.py
	- test.py
	- gen2.py
	- model.h5