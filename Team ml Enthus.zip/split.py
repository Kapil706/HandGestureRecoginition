import os

trainDir = "Marcel-Train"
validDir = "Validate"
testDir = "Test"

types = ["A", "B", "C", "Five", "Point", "V"]

for typename in types:
	trainCurrDir = trainDir + "/" + typename
	validCurrDir = validDir + "/" + typename
	testCurrDir = testDir + "/" + typename

	arr = os.listdir(trainCurrDir)

	n = len(arr)
	curr = int(0.4*n)
	limit = curr/2

	indexvec = [i for i in xrange(0, n)]

	from random import shuffle

	shuffle(indexvec)

	count = 0

	for i in xrange(0, curr):
		a = trainCurrDir + "/" + arr[indexvec[i]]
		b = validCurrDir + "/" + arr[indexvec[i]]
		c = testCurrDir + "/" + arr[indexvec[i]]

		if (count <= limit):
			os.rename(a, b)
		else:
			os.rename(a, c)

		count = count+1