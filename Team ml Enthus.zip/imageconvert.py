import numpy
import cv2
import os, os.path

def convertImage(imgpath):
	print imgpath

	img = cv2.imread(imgpath)

	grey = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) # 38.23 %
	
	th1 = cv2.adaptiveThreshold(grey,255,cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY,11,2) #46.47 %

	#ret2,th2 = cv2.threshold(grey,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU) # 40 %

	#blur = cv2.GaussianBlur(grey,(5,5),0)
	#ret3,th3 = cv2.threshold(blur,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU) # 42.94 %

	#os.remove(imgpath)
	#color = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)

	#bfilter =cv2.bilateralFilter(color,20,50,100)
	#grey = cv2.cvtColor(bfilter, cv2.COLOR_BGR2GRAY)
	#ret,grey =cv2.threshold(grey,0,255,cv2.THRESH_OTSU)

	os.remove(imgpath)

	#imgpath = imgpath.replace(".ppm", ".png")

	#value = (35, 35)
	#blurred = cv2.GaussianBlur(grey, value, 0)
	#blurred = cv2.medianBlur(grey, 5)

	# thresholdin: Otsu's Binarization method
	#_, thresh = cv2.threshold(grey, 127, 255, cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)

	#cv2.imshow('image', blurred)
	#cv2.waitKey(0)

	cv2.imwrite(imgpath, th1)

rootdirs = ["Marcel-Train", "cross_validation_data"] #"Marcel-Train"
types = ["A", "B", "C", "Five", "Point", "V"]

for rootdir in rootdirs:
	for type in types:
		subdir = rootdir + "/" + type

		arr = os.listdir(subdir)

		for filename in arr:
			filepath = subdir + "/" + filename
			convertImage(filepath)
